// Copyright 2026 Carlos Antonio de Oliveira Piquet. SPDX-License-Identifier: GPL-3.0-or-later.
// All speech output uses Gemini audio; never activate browser or Windows TTS.
define(['local_lumen10_voiceaccess/speech_support'], function(SpeechSupport) {
    'use strict';
    function init(strings) {
        const install = document.querySelector('[name=installvoice]');
        install?.addEventListener('click', async () => {
            install.disabled = true;
            const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const ok = await SpeechSupport.install(Recognition, document.documentElement.lang);
            install.textContent = ok ? strings.installed : strings.localunsupported;
            install.disabled = false;
        });
        const select = document.querySelector('select[name=voiceuri]');
        const button = document.querySelector('[name=voicetest]');
        const status = document.getElementById('l10va-voice-test-status');
        const announce = text => {if (status) {status.textContent = text;}};
        if (!select || !button) {
            return;
        }
        select.disabled = true;
        select.replaceChildren(new Option('Gemini — Sulafat', ''));
        let audio = null;
        let preview = 0;
        let timeout;
        button.addEventListener('click', () => {
            const current = ++preview;
            clearTimeout(timeout);
            if (audio) {audio.pause();audio = null;}
            const finish = text => {
                if (current !== preview) {return;}
                preview++;
                clearTimeout(timeout);
                if (audio) {audio.pause();audio = null;}
                announce(text);
            };
            try {
            window.speechSynthesis?.cancel();
            audio = new Audio((window.M?.cfg?.wwwroot || '') + '/local/lumen10_voiceaccess/pix/va_voicesample_sulafat.wav');
            audio.volume = Math.max(0, Math.min(1, Number(document.querySelector('[name=volume]')?.value ?? 1)));
            audio.playbackRate = Math.max(.5, Math.min(2, Number(document.querySelector('[name=rate]')?.value) || 1));
            audio.onended = () => finish(strings.done);
            audio.onerror = () => finish(strings.failed);
            announce(strings.testing);
            timeout = setTimeout(() => {
                finish(strings.failed);
                window.speechSynthesis?.cancel();
            }, 15000);
            audio.play().catch(() => finish(strings.failed));
            } catch (error) {
                finish(strings.failed);
            }
        });
        window.addEventListener('pagehide', () => {
            preview++;
            clearTimeout(timeout);
            window.speechSynthesis?.cancel();
            if (audio) {audio.pause();audio = null;}
        });
    }
    return {init};
});
