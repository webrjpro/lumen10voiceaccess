// Copyright 2026 Carlos Antonio de Oliveira Piquet. SPDX-License-Identifier: GPL-3.0-or-later.
// Optional native on-device recognition. Never falls back to cloud without consent.
define([], function() {
    'use strict';
    async function prepare(Recognition, lang, local) {
        if (!Recognition) {
            return {error:'unavailable'};
        }
        const recognition = new Recognition();
        recognition.lang = lang;
        if (!local) {
            return {recognition};
        }
        if (!('processLocally' in recognition) || typeof Recognition.available !== 'function') {
            return {error:'localunsupported'};
        }
        try {
            const state = await Recognition.available({langs:[lang],processLocally:true});
            if (state !== 'available') {
                return {error:state === 'downloadable' || state === 'downloading' ? 'localinstall' : 'localunsupported'};
            }
            recognition.processLocally = true;
            return {recognition};
        } catch (error) {
            return {error:'localunsupported'};
        }
    }
    async function install(Recognition, lang) {
        if (!Recognition || typeof Recognition.install !== 'function' || typeof Recognition.available !== 'function') {
            return false;
        }
        try {
            if (await Recognition.available({langs:[lang],processLocally:true}) === 'available') {
                return true;
            }
            return await Recognition.install({langs:[lang],processLocally:true}) === true;
        } catch (error) {
            return false;
        }
    }
    return {prepare,install};
});
