// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <http://www.gnu.org/licenses/>.

/**
 * Engine support.
 * @module mod_lumen10voiceaccess/engine
 * @copyright 2026 Carlos Antonio de Oliveira Piquet
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    const normalise = (text) =>
        String(text || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .toLowerCase()
            .replace(/[.,!?;:]+$/g, '')
            .trim()
            .replace(/\s+/g, ' ');

    const wakePattern =
        // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
        /^(?:(?:ol[aá]|oi|ei|hey|ok|bom dia|boa tarde|boa noite)\s+)?(?:lumendez|(?:l[uú]me[nm]?|lumi[nm]?|ilume[nm]?|luma|luna|nume[nm]?|lu\s+mende[sz]|assistente|rob[oô])(?:\s*(?:dez|10|das|de))?|(?:volume|homem)\s*(?:dez|10))(?=[\s,:;.!?-]|$)[\s,:;.!?-]*(?:(?:dez|10)(?=[\s,:;.!?-]|$)[\s,:;.!?-]*)?/i;

    const stripWake = (text) =>
        String(text || '')
            .trim()
            .replace(wakePattern, '')
            .trim();

    const hasWake = (text) => wakePattern.test(String(text || '').trim());
    /**
     * Spoken Number.
     * @param {*} value Input to this operation.
     */
    function spokenNumber(value) {
        const n = normalise(value).replace(/^(?:opcao|item|numero|alternativa|curso|atividade|aula)\s+/, '');

        if (/^\d{1,3}$/.test(n)) {
            return Number(n);
        }

        const small = {
            um: 1,
            uma: 1,
            primeiro: 1,
            primeira: 1,
            dois: 2,
            duas: 2,
            segundo: 2,
            segunda: 2,
            tres: 3,
            terceiro: 3,
            terceira: 3,
            quatro: 4,
            quarto: 4,
            quarta: 4,
            cinco: 5,
            quinto: 5,
            quinta: 5,
            seis: 6,
            sexto: 6,
            sexta: 6,
            sete: 7,
            setimo: 7,
            setima: 7,
            oito: 8,
            oitavo: 8,
            oitava: 8,
            nove: 9,
            nono: 9,
            nona: 9,
            dez: 10,
            decimo: 10,
            decima: 10,
            onze: 11,
            doze: 12,
            treze: 13,
            catorze: 14,
            quatorze: 14,
            quinze: 15,
            dezesseis: 16,
            dezessete: 17,
            dezoito: 18,
            dezenove: 19,
            one: 1,
            two: 2,
            three: 3,
            four: 4,
            five: 5,
            six: 6,
            seven: 7,
            eight: 8,
            nine: 9,
            ten: 10
        };
        const tens = {
            vinte: 20,
            trinta: 30,
            quarenta: 40,
            cinquenta: 50,
            sessenta: 60,
            setenta: 70,
            oitenta: 80,
            noventa: 90
        };
        const hundreds = {
            cem: 100,
            cento: 100,
            duzentos: 200,
            trezentos: 300,
            quatrocentos: 400,
            quinhentos: 500
        };

        if (small[n] || tens[n] || hundreds[n]) {
            return small[n] || tens[n] || hundreds[n];
        }

        const parts = n.split(' e ');

        if (parts.length === 2 && hundreds[parts[0]] && (small[parts[1]] || tens[parts[1]])) {
            return hundreds[parts[0]] + (small[parts[1]] || tens[parts[1]]);
        }

        if (parts.length === 2 && tens[parts[0]] && small[parts[1]] < 10) {
            return tens[parts[0]] + small[parts[1]];
        }

        if (parts.length === 3 && hundreds[parts[0]] && tens[parts[1]] && small[parts[2]] < 10) {
            return hundreds[parts[0]] + tens[parts[1]] + small[parts[2]];
        }

        return null;
    }
    /**
     * Format Dictation.
     * @param {String} text Input to this operation.
     */
    function formatDictation(text) {
        return String(text || '')
            .replace(/\s+(?:ponto de interrogacao|ponto de interrogação)(?=\s|$|[.,!?;:])/gi, '?')
            .replace(/\s+(?:ponto de exclamacao|ponto de exclamação)(?=\s|$|[.,!?;:])/gi, '!')
            .replace(/\s+(?:ponto e virgula|ponto e vírgula)(?=\s|$|[.,!?;:])/gi, ';')
            .replace(/\s+dois pontos(?=\s|$|[.,!?;:])/gi, ':')
            .replace(/\s+ponto final(?=\s|$|[.,!?;:])/gi, '.')
            .replace(/\s+(?:virgula|vírgula)(?=\s|$|[.,!?;:])/gi, ',')
            .replace(/\s*(?:nova linha|quebra de linha)\s*/gi, '\n')
            .replace(/\s*(?:novo paragrafo|novo parágrafo)\s*/gi, '\n\n');
    }
    /**
     * Parse.
     * @param {String} text Input to this operation.
     */
    function parse(text) {
        const rawInput = String(text || '').trim();
        const raw = stripWake(rawInput);
        const n = normalise(raw);

        if (/\bsk-[A-Za-z0-9_-]{20,}\b/i.test(rawInput)) {
            return {
                intent: 'BLOCK_CREDENTIAL'
            };
        }

        if (!n && hasWake(rawInput)) {
            return {
                intent: 'ACTIVATE'
            };
        }

        const rules = [
            [
                'ACTIVATE',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(ativar|ativar controle por voz|ativar voz|ligar voz|ligar controle por voz|iniciar controle por voz|comecar|estou aqui|ola|oi|bom dia|boa tarde|boa noite|activate|start voice|enable voice)$/
            ],
            [
                'BRIEFING',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(o que tem na pagina|o que tem aqui|ler lista|ler opcoes|quais sao as opcoes|opcoes da pagina|listar opcoes|opcoes|lista|tem coisa nova|o que tem de novo|novidades|sem nada novo|menu de voz)$/
            ],
            ['DEACTIVATE', /^(desativar|desativar controle por voz|pausar comandos|deactivate|pause commands)$/],
            ['SECURE_LOGIN', /^(entrar com seguranca|acesso seguro|usar passkey|chave de acesso|secure login)$/],
            ['LOGIN_SUBMIT', /^(entrar|acessar|login|sign in)$/],
            ['NEXT_VOICE', /^(proxima voz|next voice)$/],
            ['PREVIOUS_VOICE', /^(voz anterior|previous voice)$/],
            ['TEST_VOICE', /^(testar voz|ouvir voz|test voice)$/],
            ['RESUME_ON', /^(ativar modo maos livres|modo maos livres|enable hands free)$/],
            ['RESUME_OFF', /^(desativar modo maos livres|sair do modo maos livres|disable hands free)$/],
            [
                'DICTATION_ON',
                /^(iniciar ditado|ativar ditado|comecar ditado|modo ditado|ligar ditado|start dictation|dictation mode)$/
            ],
            [
                'DICTATION_OFF',
                /^(parar ditado|encerrar ditado|desativar ditado|finalizar ditado|sair do ditado|stop dictation|end dictation)$/
            ],
            ['CONFIRM', /^(confirmar|confirmo|pode confirmar|sim|confirm|yes)$/],
            ['CANCEL', /^(cancelar|cancela|nao|nao confirmar|abortar|cancel|no|abort)$/],
            [
                'STOP_MIC',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(parar de ouvir|desativar microfone|desligar microfone|parar microfone|fechar microfone|stop listening|stop microphone|disable microphone)$/
            ],
            ['STOP', /^(parar|pare|silencio|calar|interromper|parar leitura|parar de falar|stop|silence|quiet)$/],
            ['REPEAT', /^(repetir|repita|falar de novo|dizer novamente|repetir ultima frase|repeat|say again)$/],
            [
                'FASTER_SPEECH',
                /^(falar mais rapido|aumentar velocidade( da voz)?|voz mais rapida|ler mais rapido|speak faster|faster speech)$/
            ],
            [
                'SLOWER_SPEECH',
                /^(falar mais devagar|diminuir velocidade( da voz)?|voz mais lenta|ler mais devagar|speak slower|slower speech)$/
            ],
            [
                'TOGGLE_CONTRAST',
                /^(alto contraste|alternar contraste|modo alto contraste|high contrast|toggle contrast)$/
            ],
            [
                'TOGGLE_LARGE_TEXT',
                /^(texto ampliado|letra grande|aumentar fonte|aumentar texto|large text|bigger text)$/
            ],
            [
                'READ_PAGE',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(ler( esta pagina| a pagina| pagina| conteudo| tudo| texto| aula)?|leia( esta pagina| a pagina| o conteudo| para mim)?|ler questao|ler pergunta|ler enunciado|read( this page| page| content| question)?)$/
            ],
            [
                'READ_HEADINGS',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(ler (os )?titulos|leia (os )?titulos|listar titulos|ler cabecalhos|listar cabecalhos|read headings|list headings)$/
            ],
            ['NEXT_HEADING', /^(proximo titulo|proximo cabecalho|titulo seguinte|next heading)$/],
            ['PREVIOUS_HEADING', /^(titulo anterior|cabecalho anterior|voltar titulo|previous heading)$/],
            ['WHERE_AM_I', /^(onde estou|em que pagina estou|qual pagina estou|resumo da pagina|where am i)$/],
            [
                'HELP',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(?:(?:dez|10)\s+)?(?:me\s+|preciso de\s+|quero\s+|pedir\s+)?(ajuda|ajudar|socorro|comandos|listar comandos|quais sao os comandos|o que posso dizer|o que posso falar|como usar|como funciona|help|commands)$/
            ],
            [
                'READ_GRADES',
                /^(ler (minhas )?notas|qual (e a )?minha nota|quais sao minhas notas|quanto tirei|ler boletim|read (my )?grades)$/
            ],
            ['OPEN_COURSES', /^(abrir |ir para |ver |acessar |mostrar )?(meus cursos|cursos|my courses|courses)$/],
            [
                'OPEN_DASHBOARD',
                /^(abrir |ir para |ver |acessar )?(painel|painel inicial|pagina inicial|inicio|dashboard|home)$/
            ],
            [
                'OPEN_GRADES',
                /^(abrir |ir para |ver |consultar |mostrar )?(minhas notas|notas|boletim|my grades|grades)$/
            ],
            ['OPEN_CALENDAR', /^(abrir |ir para |ver |consultar )?(calendario|agenda|calendar)$/],
            ['OPEN_MESSAGES', /^(abrir |ir para |ver |ler )?(mensagens|bate papo|chat|messages)$/],
            ['OPEN_NOTIFICATIONS', /^(abrir |ir para |ver |ler )?(notificacoes|avisos|alertas|notifications)$/],
            ['OPEN_PROFILE', /^(abrir |ir para |ver )?(meu perfil|perfil|minha conta|my profile|profile)$/],
            [
                'OPEN_PREFERENCES',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(abrir |ir para |ver )?(minhas preferencias|preferencias de voz|configuracoes de voz|ajustes de voz|voice preferences|voice settings)$/
            ],
            ['SCROLL_DOWN', /^(descer( a pagina)?|rolar( a pagina)?( para baixo)?|para baixo|scroll down|page down)$/],
            ['SCROLL_UP', /^(subir( a pagina)?|rolar( a pagina)? para cima|para cima|scroll up|page up)$/],
            [
                'SCROLL_TOP',
                /^(ir para o |voltar ao |rolar para o )?(topo|inicio da pagina|comeco da pagina|top of page|scroll top)$/
            ],
            [
                'SCROLL_BOTTOM',
                /^(ir para o |rolar para o )?(final da pagina|fim da pagina|rodape|bottom of page|scroll bottom)$/
            ],
            ['BACK', /^(voltar|pagina anterior|retornar|back|go back)$/],
            ['FORWARD', /^(avancar pagina|pagina seguinte|ir adiante|forward|go forward)$/],
            ['RELOAD', /^(recarregar( pagina)?|atualizar( pagina)?|reload( page)?|refresh)$/],
            [
                'LIST_CONTROLS',
                /^(listar controles|controles desta pagina|listar botoes|listar links|o que posso clicar|list controls)$/
            ],
            ['LIST_FIELDS', /^(listar campos|campos do formulario|quais campos existem|ler formulario|list fields)$/],
            [
                'LIST_SECTIONS',
                /^(listar topicos|listar secoes|topicos do curso|secoes do curso|list sections|list topics)$/
            ],
            ['NEXT_SECTION', /^(ir para )?(proximo topico|proxima secao|proxima unidade|next section|next topic)$/],
            [
                'PREVIOUS_SECTION',
                /^(ir para )?(topico anterior|secao anterior|unidade anterior|previous section|previous topic)$/
            ],
            [
                'EXPAND_SECTIONS',
                /^(expandir tudo|expandir topicos|abrir todos os topicos|mostrar todas as secoes|expand all|expand sections)$/
            ],
            ['NEXT_FIELD', /^(proximo campo|avancar campo|next field)$/],
            ['PREVIOUS_FIELD', /^(campo anterior|voltar campo|previous field)$/],
            ['CLEAR_FIELD', /^(limpar( o)? (campo|texto|editor)|apagar( o)? (campo|texto|editor)|clear field)$/],
            [
                'DELETE_LAST_WORD',
                /^(apagar ultima palavra|remover ultima palavra|deletar ultima palavra|delete last word)$/
            ],
            ['PRESS_ENTER', /^(pressionar enter|apertar enter|tecla enter|pesquisar agora|buscar agora|press enter)$/],
            [
                'SUBMIT',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(enviar( formulario| prova| tarefa| mensagem)?|salvar( formulario)?|entregar tarefa|finalizar tentativa|enviar tudo e terminar|publicar no forum|submit|save)$/
            ],
            ['NEXT_QUESTION', /^(proxima questao|proxima pergunta|next question)$/],
            [
                'LIST_ACTIVITIES',
                /^(listar atividades|minhas atividades|atividades do curso|quais sao as atividades|listar aulas|list activities)$/
            ],
            ['LIST_COURSES', /^(listar cursos|quais sao meus cursos|ler meus cursos|list courses)$/],
            [
                'NEXT_ACTIVITY',
                /^(ir para )?(proxima atividade|atividade seguinte|proxima aula|next activity|next lesson)$/
            ],
            [
                'PREVIOUS_ACTIVITY',
                /^(ir para |voltar para )?(atividade anterior|aula anterior|previous activity|previous lesson)$/
            ],
            [
                'VIDEO_PLAY',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(dar play( n[oa] (video|aula|videoaula|audio))?|play( n[oa] (video|aula|audio))?|reproduzir( (o |a )?(video|aula|videoaula|audio|midia|transmissao|gravacao))?|tocar (o |a )?(video|aula|videoaula|audio)|iniciar (o |a )?(video|aula|videoaula|audio)|continuar (o |a )?(video|aula|videoaula|audio)|assistir (a )?(aula|video|videoaula)|retomar (o )?(video|aula)|play video|start video|resume video)$/
            ],
            [
                'VIDEO_PAUSE',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(dar pause( n[oa] (video|aula|audio))?|pause|pausar( (o |a )?(video|aula|videoaula|audio|midia|transmissao|gravacao))?|parar (o |a )?(video|aula|videoaula|audio)|pause video|stop video)$/
            ],
            [
                'VIDEO_RESTART',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(reiniciar (o |a )?(video|aula|videoaula|audio)|recomecar (o |a )?(video|aula|videoaula|audio)|voltar ao (inicio|comeco) d[oa] (video|aula)|video do inicio|restart video)$/
            ],
            [
                'VIDEO_MUTE',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(silenciar (o |a )?(video|aula|videoaula|audio)|mutar (o |a )?(video|aula|audio)|tirar( o)? som( d[oa] (video|aula|audio))?|mudo|mute video|mute)$/
            ],
            [
                'VIDEO_UNMUTE',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(ativar( o)? som( d[oa] (video|aula|audio))?|desmutar( (o |a )?(video|aula|audio))?|ligar( o)? som( d[oa] (video|aula|audio))?|voltar( o)? som|unmute video|unmute)$/
            ],
            [
                'VIDEO_VOLUME_UP',
                /^((aumentar|subir|elevar)( o)? volume( d[oa] (video|aula|audio))?|volume mais alto|volume up|increase volume)$/
            ],
            [
                'VIDEO_VOLUME_DOWN',
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^((diminuir|baixar|reduzir)( o)? volume( d[oa] (video|aula|audio))?|volume mais baixo|volume down|decrease volume)$/
            ],
            [
                'VIDEO_FULLSCREEN',
                /^(tela cheia|modo tela cheia|maximizar video|sair da tela cheia|alternar tela cheia|fullscreen|full screen)$/
            ],
            [
                'VIDEO_CAPTIONS',
                /^(ativar legendas?|desativar legendas?|alternar legendas?|mostrar legendas?|legendas|captions|subtitles)$/
            ],
            [
                'VIDEO_STATUS',
                /^(status do video|tempo do video|quanto falta( d[oa] (video|aula))?|posicao do video|video status)$/
            ]
        ];

        for (const [intent, pattern] of rules) {
            if (pattern.test(n)) {
                return {
                    intent
                };
            }
        }

        let match = raw.match(/^(?:senha|password)\s*:?\s+([\s\S]+)$/i);

        if (match) {
            return {
                intent: 'BLOCK_CREDENTIAL'
            };
        }

        match = n.match(
            // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
            /^(?:avancar|adiantar|pular)(?:\s+(?:o|a))?(?:\s+(?:video|aula|videoaula|audio))?(?:\s+em)?(?:\s+(.+?))?(?:\s+(segundos?|minutos?))?$/
        );

        if (match && (match[1] || /\b(video|aula|videoaula|audio)\b/.test(n))) {
            const num = match[1] ? spokenNumber(match[1]) : 15;

            if (num !== null) {
                const mult = match[2] && match[2].startsWith('minuto') ? 60 : 1;
                return {
                    intent: 'VIDEO_SEEK_FORWARD',
                    value: num * mult
                };
            }
        }

        match = n.match(
            // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
            /^(?:voltar|retroceder|rebobinar)(?:\s+(?:o|a))?(?:\s+(?:video|aula|videoaula|audio))?(?:\s+em)?(?:\s+(.+?))?(?:\s+(segundos?|minutos?))?$/
        );

        if (match && (match[1] || /\b(video|aula|videoaula|audio)\b/.test(n))) {
            const num = match[1] ? spokenNumber(match[1]) : 15;

            if (num !== null) {
                const mult = match[2] && match[2].startsWith('minuto') ? 60 : 1;
                return {
                    intent: 'VIDEO_SEEK_BACKWARD',
                    value: num * mult
                };
            }
        }

        if (/^(acelerar (o )?(video|aula)|video mais rapido|faster video)$/.test(n)) {
            return {
                intent: 'VIDEO_SPEED',
                value: 'faster'
            };
        }

        if (/^(desacelerar (o )?(video|aula)|video mais lento|slower video)$/.test(n)) {
            return {
                intent: 'VIDEO_SPEED',
                value: 'slower'
            };
        }

        if (/^(velocidade normal|velocidade padrao|normal speed)$/.test(n)) {
            return {
                intent: 'VIDEO_SPEED',
                value: 1
            };
        }

        match = n.match(/^velocidade(?:\s+d[oa]\s+(?:video|aula))?\s+(\d+(?:[.,]\d+)?|um e meio|dois|um)$/);

        if (match) {
            const rawSpeed =
                match[1] === 'um e meio'
                    ? 1.5
                    : match[1] === 'dois'
                      ? 2
                      : match[1] === 'um'
                        ? 1
                        : Number(match[1].replace(',', '.'));

            if (Number.isFinite(rawSpeed) && rawSpeed >= 0.25 && rawSpeed <= 3) {
                return {
                    intent: 'VIDEO_SPEED',
                    value: rawSpeed
                };
            }
        }

        match = raw.match(/^(?:abrir(?: a)? atividade|abrir(?: a)? aula|entrar na atividade|open activity)\s+(.+)$/i);

        if (match) {
            return {
                intent: 'OPEN_ACTIVITY',
                value: match[1]
            };
        }

        match = raw.match(/^(?:abrir(?: o)? curso|entrar no curso|acessar(?: o)? curso|open course)\s+(.+)$/i);

        if (match) {
            return {
                intent: 'OPEN_COURSE',
                value: match[1]
            };
        }

        match = raw.match(/^(?:entrar com|sign in with)\s+(.+)$/i);

        if (match) {
            return {
                intent: 'SECURE_LOGIN',
                value: match[1]
            };
        }

        match = raw.match(/^(?:preencher|preencha|fill)\s+(?:(?:o\s+)?campo\s+)?(.+?)\s+(?:com|with)\s+([\s\S]+)$/i);

        if (match) {
            if (/^(senha|password|chave|token|secret|api.?key)$/i.test(normalise(match[1]))) {
                return {
                    intent: 'BLOCK_CREDENTIAL'
                };
            }

            if (/^(usuario|usuário|username|identificacao|login)$/i.test(normalise(match[1]))) {
                return {
                    intent: 'LOGIN_USERNAME',
                    field: match[1],
                    value: match[2]
                };
            }

            return {
                intent: 'FILL_FIELD',
                field: match[1],
                value: match[2]
            };
        }

        match =
            raw.match(/^(?:escrever|escreva|digitar|digite)\s+(?:no|o)\s+campo\s+(.+?)\s*:\s*([\s\S]+)$/i) ||
            raw.match(/^(?:escrever|escreva|digitar|digite)\s+([\s\S]+?)\s+no\s+campo\s+(.+)$/i);

        if (match) {
            const isColon = /(?:no|o)\s+campo\s+.+?:/i.test(raw);
            const fld = isColon ? match[1] : match[2];
            const val = isColon ? match[2] : match[1];

            if (/^(senha|password|chave|token|secret|api.?key)$/i.test(normalise(fld))) {
                return {
                    intent: 'BLOCK_CREDENTIAL'
                };
            }

            return {
                intent: 'FILL_FIELD',
                field: fld,
                value: val
            };
        }

        match = raw.match(/^(?:usuario|usuário|username)\s*:?\s+([\s\S]+)$/i);

        if (match) {
            return {
                intent: 'LOGIN_USERNAME',
                value: match[1]
            };
        }

        match = raw.match(
            /^(?:escreva|escrever|digite|digitar|ditar|inserir texto|adicionar texto|write|type)\s*:?\s+([\s\S]+)$/i
        );

        if (match) {
            return {
                intent: 'DICTATE',
                value: match[1]
            };
        }

        match = n.match(
            // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
            /^(?:(?:clicar|clique|click)(?:\s+(?:em|no|na))?(?:\s+(?:numero|item|opcao|botao|number|option))?\s+|(?:numero|item|opcao|atalho)\s+)(.+)$/
        );

        if (match && spokenNumber(match[1]) !== null) {
            return {
                intent: 'CLICK_NUMBER',
                value: spokenNumber(match[1])
            };
        }

        match = n.match(
            /^(?:(?:selecionar|marcar|escolher)\s+)?(?:alternativa|letra|resposta|option|answer)\s+([a-z])$/
        );

        if (match) {
            return {
                intent: 'SELECT_ANSWER',
                value: match[1]
            };
        }

        match = raw.match(/^(?:(?:focar|ir para(?: o)?|selecionar)\s+)?(?:campo|field)\s+(.+)$/i);

        if (match) {
            return {
                intent: 'FOCUS_FIELD',
                value: match[1]
            };
        }

        match = raw.match(/^(?:escolher|selecionar opcao|choose)\s+(.+)$/i);

        if (match) {
            return {
                intent: 'CHOOSE_OPTION',
                value: match[1]
            };
        }

        match = raw.match(/^(?:abrir|clicar(?: em| no| na| no botao)?|acessar|open|click)\s+(.+)$/i);

        if (!match && /senha|password|api.?key|secret|token|credencia[il]|chave de api/i.test(n)) {
            return {
                intent: 'BLOCK_CREDENTIAL'
            };
        }

        return match
            ? {
                  intent: 'CLICK_NAME',
                  value: match[1]
              }
            : {
                  intent: 'UNKNOWN'
              };
    }
    /**
     * Create.
     * @param {Object} options Input to this operation.
     */
    function create(options) {
        const doc = options.document || document;
        const win = doc.defaultView;
        const s = options.strings;
        let result = {
            ok: true
        };
        let lastSpoken = '';

        const say = (message) => {
            const code =
                message === s.notfound
                    ? 'targetmissing'
                    : message === s.blocked
                      ? 'blocked'
                      : message === s.expired
                        ? 'expired'
                        : message === s.unknown
                          ? 'unknown'
                          : '';

            if (code) {
                result = {
                    ok: false,
                    code,
                    recoverable: code === 'targetmissing'
                };
            }

            if (message) {
                lastSpoken = String(message);
            }

            options.say(message);
        };

        let field = null;
        let blockedFieldSelected = false;
        let numbered = [];
        let pending = null;
        let pendingTimer = null;
        let focused = null;
        let headingIndex = -1;
        let sectionIndex = -1;

        const visible = (el) =>
            el &&
            el.isConnected &&
            !el.closest('#l10va, [hidden], [inert], [aria-hidden="true"]') &&
            win.getComputedStyle(el).display !== 'none' &&
            win.getComputedStyle(el).visibility !== 'hidden' &&
            [...ancestors(el)].every(
                (node) =>
                    win.getComputedStyle(node).display !== 'none' && win.getComputedStyle(node).visibility !== 'hidden'
            ) &&
            el.getClientRects().length > 0;
        /**
         *
         * @param {HTMLElement} el Input to this operation.
         */
        function* ancestors(el) {
            for (let node = el.parentElement; node; node = node.parentElement) {
                yield node;
            }
        }

        // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
        const modal = () => [...doc.querySelectorAll('[role="dialog"], dialog[open]')].filter(visible).pop(); // Global controls include Moodle menus, sidebars and activities, regardless of category.

        const scope = () => modal() || doc.body;

        const page = () => modal() || doc.querySelector('main, [role="main"], #region-main') || doc.body;

        const label = (el) => {
            const ids = (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
            const labelled = ids
                .map((id) => doc.getElementById(id)?.textContent || '')
                .join(' ')
                .trim();
            return (
                labelled ||
                el.getAttribute('aria-label') ||
                [...(el.labels || [])].map((x) => x.textContent).join(' ') ||
                el.getAttribute('placeholder') ||
                el.getAttribute('alt') ||
                el.getAttribute('title') ||
                (el.matches('input[type=submit], input[type=button]') ? el.value : '') ||
                (el.matches('input,textarea,select') ? el.name : el.textContent) ||
                ''
            )
                .replace(/\s+/g, ' ')
                .trim()
                .slice(0, 200);
        };

        const controls = () =>
            [
                ...scope().querySelectorAll(
                    'a[href],button,input:not([type=hidden]),textarea,select,[role=button],[contenteditable=true]'
                )
            ].filter((el) => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && label(el));

        const fields = () => controls().filter((el) => el.matches('input,textarea,select,[contenteditable=true]'));

        const editable = (el) =>
            el &&
            visible(el) &&
            !el.disabled &&
            !el.readOnly &&
            !el.closest('[data-voiceaccess-private]') &&
            (el.matches('textarea,[contenteditable=true],.editor_atto_content') ||
                (el.matches('input') &&
                    ['text', 'search', 'email', 'tel', 'url', 'number', ''].includes(el.type || 'text'))) &&
            !/(pass|senha|token|secret|api.?key|chave|credential|cardnumber|cvv)/i.test(
                (el.name || '') + ' ' + (el.id || '') + ' ' + (el.autocomplete || '')
            );

        const snapshot = (el) =>
            [
                el.outerHTML,
                el.value,
                el.checked,
                el.form?.getAttribute('action'),
                el.form?.getAttribute('method'),
                win.location.href
            ].join('|');

        const clearPending = () => {
            pending = null;
            win.clearTimeout(pendingTimer);
            options.confirmation(false);
        };

        const focus = (el) => {
            if (focused) {
                focused.classList.remove('l10va-focus');
            }

            focused = el;
            el.classList.add('l10va-focus');
            el.focus({
                preventScroll: true
            });
            el.scrollIntoView({
                block: 'center',
                behavior: 'auto'
            });
        };

        const available = (el) => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true';

        const directExecution = !options.document && !Array.isArray(win.__speech);

        const request = (el, action) => {
            if (!available(el)) {
                say(s.notfound);
                return;
            } // Browser-native file dialogs and password fields are intentionally delegated to assistive technology.

            if (el.matches('input[type=file],input[type=password]')) {
                say(s.blocked);
                return;
            }

            clearPending();

            if (directExecution && !options.navigation?.simple) {
                action();
                return;
            }

            pending = {
                el,
                action,
                fingerprint: snapshot(el),
                expiry: Date.now() + 20000
            };
            options.confirmation(true);
            say(s.confirm.replace('{$a}', label(el) || s.run));
            pendingTimer = win.setTimeout(() => {
                clearPending();
                say(s.expired);
            }, 20000);
        };

        const activate = (el) =>
            request(el, () => {
                if (el.matches('a[href]')) {
                    const url = new win.URL(el.getAttribute('href'), win.location.href);

                    if (!['https:', 'http:'].includes(url.protocol) || url.origin !== win.location.origin) {
                        say(s.blocked);
                        return;
                    } // Moodle must perform its own authentication, availability and capability checks.
                }

                el.click();

                if (directExecution) {
                    say(s.done);
                }
            });
        /**
     * Read Text.
         * @param {HTMLElement} el Input to this operation.
         */
        function readText(el) {
            const walker = doc.createTreeWalker(el, win.NodeFilter.SHOW_TEXT);
            const parts = [];
            let node;

            while ((node = walker.nextNode())) {
                const parent = node.parentElement;

                if (
                    visible(parent) &&
                    !parent.closest(
                        // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                        'script,style,nav,input,textarea,select,[contenteditable],[data-voiceaccess-private],#l10va,.l10va-flow-tools,#l10va-learning-header'
                    )
                ) {
                    parts.push(node.textContent);
                }
            }

            return parts.join(' ').replace(/\s+/g, ' ').trim().slice(0, 16000);
        }
        /**
     * Unique.
         * @param {Array} items Input to this operation.
         * @param {String} name Input to this operation.
         */
        function unique(items, name) {
            const exact = items.filter((el) => normalise(label(el)) === normalise(name));
            const found = exact.length ? exact : items.filter((el) => normalise(label(el)).includes(normalise(name)));
            return found.length === 1 ? found[0] : null;
        }
        /**
     * Write Field.
         * @param {HTMLElement} el Input to this operation.
         * @param {String} rawText Input to this operation.
         * @param {Boolean} clear Input to this operation.
         */
        function writeField(el, rawText, clear = false) {
            const value = clear ? '' : formatDictation(rawText);

            if (el.isContentEditable || el.matches('[contenteditable=true],.editor_atto_content')) {
                el.textContent = clear ? '' : el.textContent ? el.textContent + ' ' + value : value;
                el.dispatchEvent(
                    new win.Event('input', {
                        bubbles: true
                    })
                );
                el.dispatchEvent(
                    new win.Event('change', {
                        bubbles: true
                    })
                );
                say(s.dictated);
                return;
            }

            if (!clear && el.type === 'number') {
                if (!/^-?\d+([.,]\d+)?$/.test(value)) {
                    say(s.blocked);
                    return;
                }

                el.value = value.replace(',', '.');
            } else if (clear) {
                el.value = '';
            } else {
                const start = el.selectionStart ?? el.value.length;
                const end = el.selectionEnd ?? start;
                el.value = el.value.slice(0, start) + value + el.value.slice(end);

                if (typeof el.setSelectionRange === 'function') {
                    try {
                        el.setSelectionRange(start + value.length, start + value.length);
                    } catch (e) {
                        // Email inputs do not support text selection.
                    }
                }
            }

            el.dispatchEvent(
                new win.Event('input', {
                    bubbles: true
                })
            );
            el.dispatchEvent(
                new win.Event('change', {
                    bubbles: true
                })
            );
            say(s.dictated);
        }
        /**
     * Resolve Editable Target.
         */
        function resolveEditableTarget() {
            if (field) {
                return editable(field) ? field : null;
            }

            if (blockedFieldSelected) {
                return null;
            }

            if (doc.activeElement && editable(doc.activeElement)) {
                field = doc.activeElement;
                return field;
            }

            const candidates = [
                ...page().querySelectorAll('textarea,[contenteditable=true],.editor_atto_content,input')
            ].filter(editable);

            if (candidates.length === 1) {
                field = candidates[0];
                focus(field);
                return field;
            }

            return null;
        }
        /**
     * Find Media.
         */
        function findMedia() {
            const media = doc.querySelector('#aulaonline-video, .video-js video, main video, main audio, video, audio');
            const vjs = media?.player || (win.videojs && media?.id && win.videojs.getPlayers?.()?.[media.id]) || null;
            const iframe = doc.querySelector(
                'iframe[src*="youtube.com"],iframe[src*="youtu.be"],iframe[src*="vimeo.com"],iframe[src*="player"]'
            );
            return {
                media,
                vjs,
                iframe
            };
        }
        /**
     * Control Media.
         * @param {Object} command Input to this operation.
         */
        function controlMedia(command) {
            const {media, vjs, iframe} = findMedia();
            const retryBtn = doc.querySelector('.ao-player-retry:not([hidden])');

            if (command.intent === 'VIDEO_PLAY') {
                if (retryBtn && visible(retryBtn)) {
                    retryBtn.click();
                }

                if (media) {
                    try {
                        const p = vjs?.play ? vjs.play() : media.play?.();

                        if (p && typeof p.catch === 'function') {
                            p.catch(() => doc.querySelector('.vjs-play-control, .vjs-big-play-button')?.click());
                        }
                    } catch (e) {
                        doc.querySelector('.vjs-play-control, .vjs-big-play-button')?.click();
                    }

                    say(s.videoplaying || s.done);
                    return;
                }

                if (iframe?.contentWindow) {
                    iframe.contentWindow.postMessage(
                        JSON.stringify({
                            event: 'command',
                            func: 'playVideo',
                            args: []
                        }),
                        '*'
                    );
                    iframe.contentWindow.postMessage(
                        JSON.stringify({
                            method: 'play'
                        }),
                        '*'
                    );
                    say(s.videoplaying || s.done);
                    return;
                }

                say(s.notfound);
                return;
            }

            if (command.intent === 'VIDEO_PAUSE') {
                if (media) {
                    if (vjs?.pause) {
                        vjs.pause();
                    } else {
                        media.pause?.();
                    }

                    say(s.videopaused || s.done);
                    return;
                }

                if (iframe?.contentWindow) {
                    iframe.contentWindow.postMessage(
                        JSON.stringify({
                            event: 'command',
                            func: 'pauseVideo',
                            args: []
                        }),
                        '*'
                    );
                    iframe.contentWindow.postMessage(
                        JSON.stringify({
                            method: 'pause'
                        }),
                        '*'
                    );
                    say(s.videopaused || s.done);
                    return;
                }

                say(s.notfound);
                return;
            }

            if (!media) {
                say(s.notfound);
                return;
            }

            if (command.intent === 'VIDEO_RESTART') {
                media.currentTime = 0;
                media.play?.();
                say(s.videorestarted || s.done);
            } else if (command.intent === 'VIDEO_SEEK_FORWARD' || command.intent === 'VIDEO_SEEK_BACKWARD') {
                const delta = Number(command.value) || 15;
                const next = (media.currentTime || 0) + (command.intent === 'VIDEO_SEEK_FORWARD' ? delta : -delta);
                const max = Number.isFinite(media.duration) && media.duration > 0 ? media.duration : next;
                media.currentTime = Math.max(0, Math.min(max, next));
                const tpl = command.intent === 'VIDEO_SEEK_FORWARD' ? s.videoseekforward : s.videoseekbackward;
                say(tpl ? tpl.replace('{$a}', String(delta)) : s.done);
            } else if (command.intent === 'VIDEO_MUTE' || command.intent === 'VIDEO_UNMUTE') {
                media.muted = command.intent === 'VIDEO_MUTE';

                if (!media.muted && media.volume === 0) {
                    media.volume = 1;
                }

                say(media.muted ? s.videomuted || s.done : s.videounmuted || s.done);
            } else if (command.intent === 'VIDEO_VOLUME_UP' || command.intent === 'VIDEO_VOLUME_DOWN') {
                media.muted = false;
                const step = command.intent === 'VIDEO_VOLUME_UP' ? 0.2 : -0.2;
                media.volume = Math.max(0, Math.min(1, Number(((media.volume ?? 1) + step).toFixed(2))));
                const pct = Math.round(media.volume * 100);
                say(s.videovolume ? s.videovolume.replace('{$a}', String(pct)) : s.done);
            } else if (command.intent === 'VIDEO_SPEED') {
                const cur = media.playbackRate || 1;
                const nextRate =
                    command.value === 'faster'
                        ? Math.min(2, Number((cur + 0.25).toFixed(2)))
                        : command.value === 'slower'
                          ? Math.max(0.5, Number((cur - 0.25).toFixed(2)))
                          : Number(command.value) || 1;
                media.playbackRate = nextRate;
                say(s.videospeed ? s.videospeed.replace('{$a}', String(nextRate)) : s.done);
            } else if (command.intent === 'VIDEO_FULLSCREEN') {
                const fsBtn = doc.querySelector('.vjs-fullscreen-control');

                if (fsBtn && visible(fsBtn)) {
                    fsBtn.click();
                } else {
                    const host = media.closest('#aulaonline-root, .video-js') || media;

                    if (doc.fullscreenElement) {
                        doc.exitFullscreen?.();
                    } else {
                        host.requestFullscreen?.();
                    }
                }

                say(s.videofullscreen || s.done);
            } else if (command.intent === 'VIDEO_CAPTIONS') {
                const tracks = media.textTracks ? [...media.textTracks] : [];
                tracks.forEach((t) => {
                    t.mode = t.mode === 'showing' ? 'hidden' : 'showing';
                });
                say(s.videocaptions || s.done);
            } else if (command.intent === 'VIDEO_STATUS') {
                const cur = Math.floor(media.currentTime || 0);
                const dur = Number.isFinite(media.duration) ? Math.floor(media.duration) : 0;

                const fmt = (sec) => Math.floor(sec / 60) + 'm' + String(sec % 60).padStart(2, '0') + 's';

                say(
                    (media.paused ? 'Pausado' : 'Em reprodução') +
                        ' em ' +
                        fmt(cur) +
                        (dur ? ' de ' + fmt(dur) : '') +
                        ', velocidade ' +
                        (media.playbackRate || 1) +
                        'x.'
                );
            }
        }

        const routes = {
            OPEN_COURSES: '/my/courses.php',
            OPEN_DASHBOARD: '/my/',
            OPEN_GRADES: '/grade/report/overview/index.php',
            OPEN_CALENDAR: '/calendar/view.php',
            OPEN_MESSAGES: '/message/index.php',
            OPEN_NOTIFICATIONS: '/message/output/popup/notifications.php',
            OPEN_PROFILE: '/user/profile.php',
            OPEN_PREFERENCES: '/mod/lumen10voiceaccess/preferences.php'
        };
        const navigation = options.navigation || {
            courses: [],
            activities: [],
            sections: [],
            grades: [],
            whatsnew: [],
            currentcm: 0
        };

        const route = (intent) =>
            navigation.simple && navigation.routes?.[intent]
                ? navigation.routes[intent]
                : options.root + routes[intent];

        let activeList = [];

        const cleanWords = (text) =>
            normalise(text)
                .replace(/[-.,!?;:()/\\"'«»“”–—_]+/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        /**
     * Edit Dist.
         * @param {*} a Input to this operation.
         * @param {*} b Input to this operation.
         */
        function editDist(a, b) {
            if (a === b) {
                return 0;
            }

            if (!a.length) {
                return b.length;
            }

            if (!b.length) {
                return a.length;
            }

            const row = Array.from(
                {
                    length: b.length + 1
                },
                (_, i) => i
            );

            for (let i = 1; i <= a.length; i++) {
                let prev = i;

                for (let j = 1; j <= b.length; j++) {
                    const val = a[i - 1] === b[j - 1] ? row[j - 1] : Math.min(row[j - 1] + 1, prev + 1, row[j] + 1);
                    row[j - 1] = prev;
                    prev = val;
                }

                row[b.length] = prev;
            }

            return row[b.length];
        }
        /**
     * Word Sim.
         * @param {*} a Input to this operation.
         * @param {*} b Input to this operation.
         */
        function wordSim(a, b) {
            if (a === b) {
                return 1;
            }

            const sa = a.replace(/oes$/, 'ao').replace(/s$/, '');
            const sb = b.replace(/oes$/, 'ao').replace(/s$/, '');

            if (sa === sb && sa.length >= 3) {
                return 0.96;
            }

            if (sa.length >= 4 && sb.length >= 4 && (sa.startsWith(sb) || sb.startsWith(sa))) {
                return 0.88;
            }

            const minLen = Math.min(a.length, b.length);

            if (minLen >= 5) {
                const d = editDist(a, b);

                if (d <= 1) {
                    return 0.88;
                }

                if (minLen >= 7 && d <= 2) {
                    return 0.8;
                }
            }

            return 0;
        }
        /**
     * Build Page List.
         */
        function buildPageList() {
            const list = [];
            const seen = new Set();

            const add = (item) => {
                const rawName = String(item.name || '').trim();
                const displayName = rawName.replace(/^\d{1,2}\s*[.-]\s*/, '').trim() || rawName;
                const key = cleanWords(displayName);

                if (!key || seen.has(key)) {
                    return;
                }

                seen.add(key);
                list.push({...item, name: displayName, rawName});
            };

            if (navigation.simple) {
                // The visible priority order is also the spoken order. Closed details are not menu items.
                const targets = [...doc.querySelectorAll('[data-l10va-flow-item]')].filter((el) => visible(el));

                if (!targets.length) {
                    [...page().querySelectorAll('a[href],button')]
                        .filter((el) => visible(el) && !el.disabled && !el.closest('.l10va-flow-tools'))
                        .slice(0, 8)
                        .forEach((el) =>
                            add({
                                name: label(el),
                                type: 'el',
                                el
                            })
                        );
                } else {
                    targets.forEach((el) =>
                        add({
                            name: label(el),
                            type: 'el',
                            el
                        })
                    );
                }

                [
                    {
                        name: 'Painel',
                        type: 'url',
                        url: route('OPEN_DASHBOARD')
                    },
                    {
                        name: 'Meus cursos',
                        type: 'url',
                        url: route('OPEN_COURSES')
                    }
                ].forEach(add);
                activeList = list;
                return activeList;
            }

            if (navigation.activities?.length) {
                navigation.activities.forEach((a) =>
                    add({
                        name: a.name,
                        type: 'url',
                        url: a.url
                    })
                );
            }

            if (navigation.courses?.length) {
                navigation.courses.forEach((c) =>
                    add({
                        name: c.name,
                        type: 'url',
                        url: c.url
                    })
                );
            }

            [...page().querySelectorAll('a[href],button,[role=button]')]
                .filter((el) => visible(el) && !el.disabled && label(el))
                .slice(0, 15)
                .forEach((el) =>
                    add({
                        name: label(el),
                        type: 'el',
                        el
                    })
                );
            [
                {
                    name: 'Meus cursos',
                    type: 'url',
                    url: options.root + routes.OPEN_COURSES
                },
                {
                    name: 'Painel inicial',
                    type: 'url',
                    url: options.root + routes.OPEN_DASHBOARD
                },
                {
                    name: 'Minhas notas',
                    type: 'url',
                    url: options.root + routes.OPEN_GRADES
                },
                {
                    name: 'Calendário',
                    type: 'url',
                    url: options.root + routes.OPEN_CALENDAR
                },
                {
                    name: 'Mensagens',
                    type: 'url',
                    url: options.root + routes.OPEN_MESSAGES
                }
            ].forEach(add);
            activeList = list.slice(0, 30);
            return activeList;
        }
        /**
     * Execute List Item.
         * @param {Object} item Input to this operation.
         */
        function executeListItem(item) {
            if (!item) {
                return false;
            }

            if (item.type === 'url') {
                const url = new win.URL(item.url, win.location.href);

                if (url.origin === win.location.origin && ['http:', 'https:'].includes(url.protocol)) {
                    say('Abrindo ' + item.name + '...');
                    options.navigate(url.href);
                    return true;
                }
            } else if (item.type === 'el' && item.el && available(item.el)) {
                const rawHref = item.el.matches('a[href]') ? (item.el.getAttribute('href') || '').trim() : '';

                if (
                    rawHref &&
                    !rawHref.startsWith('#') &&
                    !item.el.hasAttribute('data-action') &&
                    !item.el.hasAttribute('data-toggle')
                ) {
                    const url = new win.URL(rawHref, win.location.href);

                    if (url.origin === win.location.origin && ['http:', 'https:'].includes(url.protocol)) {
                        say('Abrindo ' + item.name + '...');
                        options.navigate(url.href);
                        return true;
                    }
                }

                activate(item.el);
                return true;
            }

            return false;
        }
        /**
     * Briefing.
         * @param {Boolean} isWelcome Input to this operation.
         */
        function briefing(isWelcome = false) {
            const items = buildPageList();
            const h1 =
                [...page().querySelectorAll('h1')]
                    .filter(visible)
                    .map((el) => el.textContent.trim())
                    .find(Boolean) ||
                navigation.coursename ||
                doc.title ||
                'Plataforma';
            const greet = isWelcome ? 'Bem-vindo' + (navigation.username ? ', ' + navigation.username : '') + '! ' : '';
            const where = 'Você está em ' + h1 + '. ';
            const news = navigation.simple
                ? ''
                : navigation.whatsnew?.length
                  ? 'Novidades: ' + navigation.whatsnew.join('. ') + '. '
                  : 'Sem nada novo no momento. ';
            const mediaInfo =
                findMedia().media || findMedia().iframe
                    ? 'Há uma videoaula nesta página: diga dar play ou pausar. '
                    : '';
            const menuText = items.length
                ? 'Opções disponíveis nesta página:\n' +
                  items
                      .slice(0, 10)
                      .map((it, idx) => idx + 1 + '. ' + it.name)
                      .join('\n') +
                  '\nO que deseja? Fale o número ou o nome de qualquer opção da lista.'
                : 'O que deseja fazer? Diga meus cursos, ler esta página ou ajuda.';
            say(greet + where + news + mediaInfo + menuText);
        }
        /**
     * Try Direct Match.
         * @param {String} phrase Input to this operation.
         */
        function tryDirectMatch(phrase) {
            const rawClean = cleanWords(stripWake(phrase));

            if (!rawClean) {
                return false;
            }

            if (!activeList.length) {
                buildPageList();
            }

            const cleaned =
                rawClean
                    .replace(
                        // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                        /^(?:eu\s+)?(?:quero|gostaria|desejo|favor|por favor|preciso|me leva|leva|ir|vai|abrir|abra|abre|acessar|acesse|acessa|entrar|entre|entra|clicar|clique|clica|escolher|escolha|escolhe|selecionar|selecione|seleciona|ver|veja|mostrar|mostre|mostra|ler|leia|assistir|assista|fazer|estudar)(?:\s+(?:ir|abrir|acessar|entrar|clicar|ver|estudar))?(?:\s+(?:para|em|no|na|nos|nas|ao|a|o|os|as|de|do|da|dos|das|pro|pra))?(?:\s+(?:opcao|item|numero|curso|aula|atividade|modulo|topico|pagina|botao|link))?(?:\s+(?:de|do|da|dos|das|o|a|os|as))?\s+/i,
                        ''
                    )
                    .replace(/^(?:opcao|item|numero|curso|aula|atividade|modulo|topico)\s+(?:de\s+|do\s+|da\s+)?/i, '')
                    .replace(/^(?:o|a|os|as|no|na|em|de|do|da)\s+/i, '')
                    .trim() || rawClean;
            const num = spokenNumber(cleaned) ?? spokenNumber(rawClean);

            if (num !== null && activeList[num - 1]) {
                return executeListItem(activeList[num - 1]);
            }

            const leadNumMatch = cleaned.match(
                // eslint-disable-next-line max-len -- Keep the fixed command pattern or selector intact.
                /^(\d{1,2}|um|uma|primeiro|primeira|dois|duas|segundo|segunda|tres|terceiro|terceira|quatro|quarto|quarta|cinco|quinto|quinta|seis|sexto|sexta|sete|setimo|setima|oito|oitavo|oitava|nove|nono|nona|dez|decimo|decima)\b/
            );

            if (leadNumMatch) {
                const leadNum = spokenNumber(leadNumMatch[1]);

                if (leadNum !== null && activeList[leadNum - 1]) {
                    return executeListItem(activeList[leadNum - 1]);
                }
            }

            if (cleaned.length < 2) {
                return false;
            }

            const stopwords = new Set([
                'o',
                'a',
                'os',
                'as',
                'de',
                'do',
                'da',
                'dos',
                'das',
                'em',
                'no',
                'na',
                'nos',
                'nas',
                'e',
                'ou',
                'para',
                'por',
                'com',
                'sem',
                'um',
                'uma',
                'ao',
                'aos',
                'curso',
                'aula',
                'atividade',
                'opcao',
                'item'
            ]);
            const pWords = cleaned.split(' ').filter((w) => w.length >= 2 && !stopwords.has(w));
            let bestItem = null;
            let bestScore = 0;
            activeList.forEach((it, idx) => {
                const itemClean = cleanWords(it.name);
                const fullClean = cleanWords(it.rawName || it.name);
                let score = 0;

                if (itemClean === cleaned || fullClean === cleaned) {
                    score = 1000 - idx;
                } else if (
                    cleaned.length >= 3 &&
                    (itemClean.includes(cleaned) || fullClean.includes(cleaned) || cleaned.includes(itemClean))
                ) {
                    const ratio =
                        Math.min(itemClean.length, cleaned.length) /
                        Math.max(1, Math.max(itemClean.length, cleaned.length));
                    score = 800 + Math.round(ratio * 150) - idx;
                } else if (pWords.length) {
                    const iWords = fullClean.split(' ').filter((w) => w.length >= 2 && !stopwords.has(w));

                    if (iWords.length) {
                        let simSum = 0;
                        let matched = 0;
                        pWords.forEach((pw) => {
                            const maxS = Math.max(0, ...iWords.map((iw) => wordSim(pw, iw)));
                            simSum += maxS;

                            if (maxS >= 0.8) {
                                matched++;
                            }
                        });
                        const userCov = simSum / pWords.length;
                        const itemCov = matched / iWords.length;

                        if (
                            matched > 0 &&
                            (userCov >= 0.65 ||
                                matched >= 2 ||
                                (pWords.length === 1 && pWords[0].length >= 4 && userCov >= 0.8))
                        ) {
                            score = Math.round(userCov * 500 + itemCov * 200) - idx;
                        }
                    }
                }

                if (score > bestScore) {
                    bestScore = score;
                    bestItem = it;
                }
            });

            if (bestItem && bestScore >= 400) {
                return executeListItem(bestItem);
            }

            const ctrl = unique(controls(), cleaned);

            if (ctrl) {
                activate(ctrl);
                return true;
            }

            return false;
        }
        /**
     * Open Known.
         * @param {Array} items Input to this operation.
         * @param {String} query Input to this operation.
         */
        function openKnown(items, query) {
            const number = spokenNumber(query);
            const qClean = cleanWords(query);
            const exact =
                number !== null
                    ? items.filter((item, index) => index === number - 1)
                    : items.filter(
                          (item) =>
                              cleanWords(item.name) === qClean ||
                              cleanWords(item.name).replace(/^\d+\s+/, '') === qClean
                      );
            const matches = exact.length
                ? exact
                : items.filter(
                      (item) => cleanWords(item.name).includes(qClean) || qClean.includes(cleanWords(item.name))
                  );

            if (matches.length !== 1) {
                if (directExecution && tryDirectMatch(query)) {
                    return;
                }

                say(s.notfound);
                return;
            }

            const url = new win.URL(matches[0].url, win.location.href);

            if (url.origin !== win.location.origin || !['http:', 'https:'].includes(url.protocol)) {
                say(s.blocked);
                return;
            }

            options.navigate(url.href);
        }
        /**
     * Login Form.
         */
        function loginForm() {
            if (!options.login || !win.location.pathname.endsWith('/login/index.php')) {
                return null;
            }

            const username = doc.querySelector('#username');
            const password = doc.querySelector('#password');

            if (!username?.form || username.form !== password?.form || !available(password)) {
                return null;
            }

            const action = new win.URL(username.form.getAttribute('action'), win.location.href);

            if (action.origin !== win.location.origin || !action.pathname.endsWith('/login/index.php')) {
                return null;
            }

            return {
                username,
                password,
                button: username.form.querySelector('#loginbtn,button[type=submit],input[type=submit]')
            };
        }
        /**
     * Run Command.
         * @param {Object} command Input to this operation.
         */
        function runCommand(command) {
            if (command.intent === 'CONFIRM') {
                const action = pending;
                clearPending();

                if (
                    !action ||
                    Date.now() > action.expiry ||
                    !available(action.el) ||
                    !scope().contains(action.el) ||
                    action.fingerprint !== snapshot(action.el)
                ) {
                    say(s.expired);
                    return;
                }

                action.action();
                return;
            } // A different command invalidates the previous confirmation.

            clearPending();

            if (command.intent.startsWith('VIDEO_')) {
                controlMedia(command);
            } else if (command.intent === 'BRIEFING') {
                briefing(false);
            } else if (/^OPEN_ITEM_(\d+)$/.test(command.intent)) {
                const idx = Number(command.intent.replace('OPEN_ITEM_', '')) - 1;

                if (!activeList.length) {
                    buildPageList();
                }

                if (!executeListItem(activeList[idx])) {
                    say(s.notfound);
                }
            } else if (command.intent === 'CANCEL') {
                say(s.cancelled);
            } else if (command.intent === 'REPEAT') {
                say(lastSpoken || s.helptext);
            } else if (command.intent === 'READ_GRADES') {
                if (navigation.grades?.length) {
                    say(
                        navigation.grades
                            .map((g) => g.course + ': nota ' + g.grade + (g.max ? ' de ' + g.max : ''))
                            .join('. ')
                    );
                } else {
                    options.navigate(options.root + routes.OPEN_GRADES);
                }
            } else if (command.intent === 'LIST_ACTIVITIES' || command.intent === 'LIST_COURSES') {
                const items = command.intent === 'LIST_ACTIVITIES' ? navigation.activities : navigation.courses;

                if (items.length) {
                    activeList = items.map((it) => ({
                        name: it.name,
                        type: 'url',
                        url: it.url
                    }));
                }

                say(items.length ? items.map((item, index) => index + 1 + '. ' + item.name).join('\n') : s.notfound);
            } else if (command.intent === 'LIST_SECTIONS') {
                const domSecs = [
                    ...page().querySelectorAll('.course-section-header h3, .sectionname, [data-for="section_title"]')
                ]
                    .filter(visible)
                    .map((el, i) => i + 1 + '. ' + el.textContent.trim());
                const list = domSecs.length
                    ? domSecs
                    : (navigation.sections || []).map((sec, i) => i + 1 + '. ' + sec.name);
                say(list.length ? list.join('\n') : s.notfound);
            } else if (command.intent === 'NEXT_SECTION' || command.intent === 'PREVIOUS_SECTION') {
                const secs = [
                    ...page().querySelectorAll('.course-section-header h3, .sectionname, [data-for="section_title"]')
                ].filter(visible);

                if (!secs.length) {
                    say(s.notfound);
                    return;
                }

                sectionIndex =
                    command.intent === 'NEXT_SECTION'
                        ? (sectionIndex + 1) % secs.length
                        : sectionIndex <= 0
                          ? secs.length - 1
                          : sectionIndex - 1;
                focus(secs[sectionIndex]);
                say(secs[sectionIndex].textContent.trim());
            } else if (command.intent === 'EXPAND_SECTIONS') {
                const collapsed = [
                    ...page().querySelectorAll(
                        '[data-toggle="collapse"][aria-expanded="false"], .collapsesection[aria-expanded="false"]'
                    )
                ].filter(available);
                collapsed.forEach((btn) => btn.click());
                say(s.done);
            } else if (command.intent === 'OPEN_ACTIVITY' || command.intent === 'OPEN_COURSE') {
                openKnown(
                    command.intent === 'OPEN_ACTIVITY' ? navigation.activities : navigation.courses,
                    String(command.value)
                );
            } else if (command.intent === 'NEXT_ACTIVITY' || command.intent === 'PREVIOUS_ACTIVITY') {
                const index = navigation.activities.findIndex((item) => item.id === navigation.currentcm);
                const step = command.intent === 'NEXT_ACTIVITY' ? 1 : -1;
                const target = index >= 0 ? navigation.activities[index + step] : navigation.activities[0];

                if (target) {
                    openKnown([target], '1');
                } else {
                    say(s.notfound);
                }
            } else if (command.intent === 'BLOCK_CREDENTIAL') {
                say(s.passwordblocked);
            } else if (command.intent === 'SECURE_LOGIN') {
                const login = loginForm();

                if (!login) {
                    say(s.blocked);
                    return;
                }

                const providers = [...doc.querySelectorAll('.login-identityproviders a[href]')].filter(available);
                const target = command.value
                    ? unique(providers, command.value)
                    : providers.length === 1
                      ? providers[0]
                      : null;

                if (target) {
                    activate(target);
                } else if (providers.length) {
                    say(s.secureloginchoose + ' ' + providers.map(label).join('. '));
                } else {
                    say(s.secureloginunavailable);
                }
            } else if (['LOGIN_USERNAME', 'LOGIN_SUBMIT'].includes(command.intent)) {
                const login = loginForm();

                if (!login) {
                    if (command.intent === 'LOGIN_USERNAME' && command.field) {
                        const el = unique(fields(), command.field);

                        if (el && editable(el)) {
                            field = el;
                            focus(el);
                            writeField(el, command.value, false);
                            return;
                        }
                    }

                    say(s.blocked);
                    return;
                }

                if (command.intent === 'LOGIN_USERNAME') {
                    const el = login.username;
                    el.value = command.value;
                    el.dispatchEvent(
                        new win.Event('input', {
                            bubbles: true
                        })
                    );
                    el.dispatchEvent(
                        new win.Event('change', {
                            bubbles: true
                        })
                    );
                    say(s.credentialfilled);
                } else {
                    if (login.password.value) {
                        activate(login.button);
                    } else {
                        say(s.secureloginunavailable);
                    }
                }
            } else if (command.intent === 'STOP') {
                options.stopSpeech();
            } else if (command.intent === 'HELP') {
                if (navigation.simple && navigation.routes?.HELP) {
                    options.navigate(navigation.routes.HELP);
                } else {
                    say(s.helptext);
                }
            } else if (command.intent === 'WHERE_AM_I') {
                if (directExecution) {
                    briefing(false);
                } else {
                    say(
                        doc.title +
                            '. ' +
                            [...page().querySelectorAll('h1')]
                                .filter(visible)
                                .map((el) => el.textContent)
                                .join('. ')
                    );
                }
            } else if (command.intent === 'READ_PAGE') {
                say(readText(page()));
            } else if (command.intent === 'READ_HEADINGS') {
                say(
                    [...page().querySelectorAll('h1,h2,h3,h4,h5,h6')]
                        .filter(visible)
                        .map((el) => el.textContent)
                        .join('. ') || s.notfound
                );
            } else if (command.intent === 'NEXT_HEADING' || command.intent === 'PREVIOUS_HEADING') {
                const heads = [...page().querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(visible);

                if (!heads.length) {
                    say(s.notfound);
                    return;
                }

                headingIndex =
                    command.intent === 'NEXT_HEADING'
                        ? (headingIndex + 1) % heads.length
                        : headingIndex <= 0
                          ? heads.length - 1
                          : headingIndex - 1;
                focus(heads[headingIndex]);
                say(heads[headingIndex].textContent.trim());
            } else if (routes[command.intent]) {
                options.navigate(route(command.intent));
            } else if (command.intent === 'SCROLL_DOWN' || command.intent === 'SCROLL_UP') {
                win.scrollBy({
                    top: (command.intent === 'SCROLL_DOWN' ? 1 : -1) * win.innerHeight * 0.7,
                    behavior: 'auto'
                });
            } else if (command.intent === 'SCROLL_TOP') {
                win.scrollTo({
                    top: 0,
                    behavior: 'auto'
                });
            } else if (command.intent === 'SCROLL_BOTTOM') {
                win.scrollTo({
                    top: doc.documentElement?.scrollHeight || 99999,
                    behavior: 'auto'
                });
            } else if (command.intent === 'BACK') {
                win.history.back();
            } else if (command.intent === 'FORWARD') {
                win.history.forward();
            } else if (command.intent === 'RELOAD') {
                win.location.reload();
            } else if (command.intent === 'LIST_CONTROLS') {
                numbered = controls().slice(0, 150);
                activeList = numbered.map((el) => ({
                    name: label(el),
                    type: 'el',
                    el
                }));
                say(s.controls + ':\n' + numbered.map((el, i) => i + 1 + '. ' + label(el)).join('\n'));
            } else if (command.intent === 'LIST_FIELDS') {
                const items = fields();
                say(items.length ? items.map((el, i) => i + 1 + '. ' + label(el)).join('\n') : s.notfound);
            } else if (command.intent === 'CLICK_NUMBER') {
                if (directExecution && activeList[command.value - 1]) {
                    executeListItem(activeList[command.value - 1]);
                    return;
                }

                if (!numbered.length) {
                    numbered = controls().slice(0, 150);
                }

                const el = numbered[command.value - 1];

                if (el && available(el) && scope().contains(el)) {
                    activate(el);
                } else {
                    say(s.notfound);
                }
            } else if (command.intent === 'CLICK_NAME') {
                if (directExecution && tryDirectMatch(command.value)) {
                    return;
                }

                const el = unique(controls(), command.value);

                if (el) {
                    activate(el);
                } else {
                    const knownAct = (navigation.activities || []).filter(
                        (a) => normalise(a.name) === normalise(command.value)
                    );
                    const knownCourse = (navigation.courses || []).filter(
                        (c) => normalise(c.name) === normalise(command.value)
                    );

                    if (knownAct.length === 1) {
                        openKnown(knownAct, '1');
                    } else if (knownCourse.length === 1) {
                        openKnown(knownCourse, '1');
                    } else {
                        say(s.notfound);
                    }
                }
            } else if (command.intent === 'FOCUS_FIELD') {
                const el = unique(fields(), command.value);

                if (el) {
                    field = el;
                    blockedFieldSelected = !editable(el);
                    focus(el);
                    say(s.focused.replace('{$a}', label(el)));
                } else {
                    const rawMatch = [...scope().querySelectorAll('input,textarea,select')].find(
                        (item) => normalise(label(item)) === normalise(command.value)
                    );

                    if (rawMatch) {
                        field = null;
                        blockedFieldSelected = true;
                    }

                    say(s.notfound);
                }
            } else if (['NEXT_FIELD', 'PREVIOUS_FIELD'].includes(command.intent)) {
                const items = fields();

                if (!items.length) {
                    say(s.notfound);
                    return;
                }

                const current = items.indexOf(field);
                const index =
                    command.intent === 'NEXT_FIELD'
                        ? (current + 1) % items.length
                        : current <= 0
                          ? items.length - 1
                          : current - 1;
                field = items[index];
                blockedFieldSelected = !editable(field);
                focus(field);
                say(s.focused.replace('{$a}', label(field)));
            } else if (command.intent === 'FILL_FIELD') {
                const el = unique(fields(), command.field);

                if (!el) {
                    say(s.notfound);
                    return;
                }

                field = el;
                blockedFieldSelected = !editable(el);

                if (!editable(el)) {
                    say(s.blocked);
                    return;
                }

                focus(el);
                writeField(el, command.value, false);
            } else if (command.intent === 'DICTATE' || command.intent === 'CLEAR_FIELD') {
                const el = command.intent === 'CLEAR_FIELD' ? field : resolveEditableTarget();

                if (!editable(el)) {
                    say(s.blocked);
                    return;
                }

                const change = () => writeField(el, command.value, command.intent === 'CLEAR_FIELD');

                if (command.intent === 'CLEAR_FIELD') {
                    request(el, change);
                } else {
                    change();
                }
            } else if (command.intent === 'DELETE_LAST_WORD') {
                const el = resolveEditableTarget();

                if (!editable(el)) {
                    say(s.blocked);
                    return;
                }

                el.value = String(el.value || '').replace(/\s*\S+\s*$/, '');
                el.dispatchEvent(
                    new win.Event('input', {
                        bubbles: true
                    })
                );
                el.dispatchEvent(
                    new win.Event('change', {
                        bubbles: true
                    })
                );
                say(s.worddeleted || s.dictated);
            } else if (command.intent === 'PRESS_ENTER') {
                const el = resolveEditableTarget();

                if (!editable(el)) {
                    say(s.blocked);
                    return;
                }

                el.dispatchEvent(
                    new win.KeyboardEvent('keydown', {
                        key: 'Enter',
                        code: 'Enter',
                        bubbles: true
                    })
                );
                say(s.enterpressed || s.done);
            } else if (command.intent === 'SELECT_ANSWER') {
                // Only the current/focused question. Multiple questions are never guessed.
                const active = doc.activeElement?.closest('.que');
                const questions = [...scope().querySelectorAll('.que')].filter(visible);
                const question = active || field?.closest('.que') || (questions.length === 1 ? questions[0] : null);

                if (!question) {
                    say(s.notfound);
                    return;
                }

                const choices = [...question.querySelectorAll('input[type=radio],input[type=checkbox]')].filter(
                    available
                );
                const el = choices[command.value.charCodeAt(0) - 97];

                if (!el) {
                    say(s.notfound);
                    return;
                }

                request(el, () => {
                    el.checked = true;
                    el.dispatchEvent(
                        new win.Event('input', {
                            bubbles: true
                        })
                    );
                    el.dispatchEvent(
                        new win.Event('change', {
                            bubbles: true
                        })
                    );
                    focus(el);
                    say(s.done);
                });
            } else if (command.intent === 'CHOOSE_OPTION') {
                if (!field?.matches('select') || !available(field)) {
                    say(s.notfound);
                    return;
                }

                const el = field;
                const exact = [...el.options].filter(
                    (o) => !o.disabled && normalise(o.textContent) === normalise(command.value)
                );
                const choices = exact.length
                    ? exact
                    : [...el.options].filter(
                          (o) => !o.disabled && normalise(o.textContent).includes(normalise(command.value))
                      );

                if (choices.length !== 1) {
                    say(s.notfound);
                    return;
                }

                const choice = choices[0];
                request(el, () => {
                    el.value = choice.value;
                    el.dispatchEvent(
                        new win.Event('change', {
                            bubbles: true
                        })
                    );
                    say(s.done);
                });
            } else if (command.intent === 'SUBMIT' || command.intent === 'NEXT_QUESTION') {
                const candidates = controls().filter((el) =>
                    command.intent === 'SUBMIT'
                        ? el.matches('button[type=submit],input[type=submit],button:not([type])') &&
                          /enviar|salvar|finalizar|entregar|publicar|submit|save|finish/i.test(label(el))
                        : el.name === 'next' ||
                          /proxima pagina|proxima questao|next page|next question/i.test(label(el))
                );

                if (candidates.length === 1) {
                    activate(candidates[0]);
                } else {
                    say(s.notfound);
                }
            } else {
                say(s.unknown);
            }
        }

        const onFocus = (event) => {
            if (
                event.target.matches('input,textarea,select,[contenteditable=true]') &&
                !event.target.closest('#l10va')
            ) {
                field = event.target;
                blockedFieldSelected = !editable(event.target);
            }
        };

        doc.addEventListener('focusin', onFocus);
        doc.addEventListener('input', clearPending);
        doc.addEventListener('change', clearPending);
        /**
     * Execute.
         * @param {Object} command Input to this operation.
         */
        function execute(command) {
            result = {
                ok: true
            };

            try {
                runCommand(command);
            } catch (error) {
                clearPending();
                result = {
                    ok: false,
                    code: 'actionfailed',
                    recoverable: false
                };
                options.say(s.commandfailed || s.notfound);
            }

            return result;
        }

        return {
            execute,
            controls,
            activate,
            focus,
            clearPending,
            label,
            visible,
            briefing,
            tryDirectMatch,
            readPage: () => readText(page()),
            canUseAI: () => !field || editable(field),
            destroy: () => {
                clearPending();
                doc.removeEventListener('focusin', onFocus);
                doc.removeEventListener('input', clearPending);
                doc.removeEventListener('change', clearPending);
                focused?.classList.remove('l10va-focus');
            }
        };
    }

    return {
        normalise,
        parse,
        create,
        hasWake,
        stripWake,
        spokenNumber
    };
});
